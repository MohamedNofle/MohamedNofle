import { z } from "zod";

export const createLeadSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters").max(100),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(9, "Invalid phone number").max(20),
  company: z.string().max(100).optional().default(""),
  sector: z.string().min(1, "Sector is required"),
  budget: z.string().min(1, "Budget is required"),
  message: z.string().max(1000).optional().default(""),
});

export const updateLeadStatusSchema = z.object({
  status: z.enum(["accepted", "rejected"]),
});
