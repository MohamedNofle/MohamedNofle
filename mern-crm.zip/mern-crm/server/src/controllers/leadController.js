import { Lead } from "../models/Lead.js";

export const createLead = async (req, res) => {
  const lead = await Lead.create(req.validatedData);
  req.io.emit("new_lead", lead);
  res.status(201).json({ success: true, data: lead });
};

export const getAllLeads = async (req, res) => {
  const leads = await Lead.find().sort({ createdAt: -1 });
  res.json({ success: true, data: leads });
};

export const updateLeadStatus = async (req, res) => {
  const lead = await Lead.findByIdAndUpdate(
    req.params.id,
    { status: req.validatedData.status },
    { new: true }
  );
  if (!lead) return res.status(404).json({ success: false, message: "Lead not found" });
  req.io.emit("lead_updated", lead);
  res.json({ success: true, data: lead });
};

export const deleteLead = async (req, res) => {
  const lead = await Lead.findByIdAndDelete(req.params.id);
  if (!lead) return res.status(404).json({ success: false, message: "Lead not found" });
  req.io.emit("lead_deleted", req.params.id);
  res.json({ success: true });
};
