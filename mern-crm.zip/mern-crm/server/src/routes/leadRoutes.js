import { Router } from "express";
import { createLead, getAllLeads, updateLeadStatus, deleteLead } from "../controllers/leadController.js";
import { validateRequest } from "../middleware/validateRequest.js";
import { createLeadSchema, updateLeadStatusSchema } from "../schemas/leadSchema.js";

const router = Router();

router.get("/", getAllLeads);
router.post("/", validateRequest(createLeadSchema), createLead);
router.patch("/:id/status", validateRequest(updateLeadStatusSchema), updateLeadStatus);
router.delete("/:id", deleteLead);

export default router;
