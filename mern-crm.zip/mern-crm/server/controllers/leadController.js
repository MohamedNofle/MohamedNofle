import Lead from "../models/Lead.js";
import { emitNewLead, emitLeadStatusUpdate } from "../socket/socketHandler.js";

const createLead = async (req, res) => {
  const lead = await Lead.create(req.body);
  emitNewLead(lead);
  res.status(201).json({ success: true, data: lead });
};

const getAllLeads = async (req, res) => {
  const leads = await Lead.find().sort({ createdAt: -1 });
  res.status(200).json({ success: true, data: leads });
};

const updateLeadStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!["accepted", "rejected"].includes(status)) {
    return res.status(400).json({ success: false, message: "Invalid status value" });
  }

  const lead = await Lead.findByIdAndUpdate(id, { status }, { new: true, runValidators: true });

  if (!lead) {
    return res.status(404).json({ success: false, message: "Lead not found" });
  }

  emitLeadStatusUpdate(lead);
  res.status(200).json({ success: true, data: lead });
};

const deleteLead = async (req, res) => {
  const lead = await Lead.findByIdAndDelete(req.params.id);

  if (!lead) {
    return res.status(404).json({ success: false, message: "Lead not found" });
  }

  res.status(200).json({ success: true, message: "Lead deleted" });
};

export { createLead, getAllLeads, updateLeadStatus, deleteLead };
