import { Router } from "express";
import { createLead, getAllLeads, updateLeadStatus, deleteLead } from "../controllers/leadController.js";
import validateLead from "../middleware/validateLead.js";

const router = Router();

router.get("/", getAllLeads);
router.post("/", validateLead, createLead);
router.patch("/:id/status", updateLeadStatus);
router.delete("/:id", deleteLead);

export default router;
