import { z } from "zod";

const leadSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(7, "Phone number is too short"),
  company: z.string().optional().default(""),
  sector: z.enum(["retail", "medical", "construction", "education", "technology", "other"]),
  budget: z.enum(["under-10k", "10k-50k", "50k-100k", "above-100k"]),
  message: z.string().optional().default(""),
});

const validateLead = (req, res, next) => {
  const result = leadSchema.safeParse(req.body);

  if (!result.success) {
    const errors = result.error.flatten().fieldErrors;
    return res.status(400).json({ success: false, errors });
  }

  req.body = result.data;
  next();
};

export default validateLead;
