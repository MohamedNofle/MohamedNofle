import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import { connectDB } from "./src/config/db.js";
import leadRoutes from "./src/routes/leadRoutes.js";
import { initSocket } from "./src/socket/socketHandler.js";

const app = express();
const httpServer = createServer(app);

const io = new Server(httpServer, {
  cors: { origin: process.env.CLIENT_URL, methods: ["GET", "POST", "PATCH", "DELETE"] },
});

app.use(cors({ origin: process.env.CLIENT_URL }));
app.use(express.json());

app.use((req, _res, next) => {
  req.io = io;
  next();
});

app.use("/api/leads", leadRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ success: false, message: "Internal server error" });
});

initSocket(io);

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  httpServer.listen(PORT, () => console.log(`Server running on port ${PORT}`));
});
