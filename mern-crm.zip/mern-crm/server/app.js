import express from "express";
import cors from "cors";
import morgan from "morgan";
import leadRoutes from "./routes/leadRoutes.js";

const createApp = () => {
  const app = express();

  app.use(cors({ origin: process.env.CLIENT_ORIGIN, credentials: true }));
  app.use(morgan("dev"));
  app.use(express.json());

  app.use("/api/leads", leadRoutes);

  app.use((err, req, res, next) => {
    const statusCode = err.statusCode || 500;
    res.status(statusCode).json({ success: false, message: err.message || "Internal Server Error" });
  });

  return app;
};

export default createApp;
