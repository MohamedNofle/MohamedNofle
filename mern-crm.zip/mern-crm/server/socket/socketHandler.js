let ioInstance = null;

const initSocket = (io) => {
  ioInstance = io;

  io.on("connection", (socket) => {
    socket.on("disconnect", () => {});
  });
};

const emitNewLead = (lead) => {
  if (ioInstance) {
    ioInstance.emit("lead:new", lead);
  }
};

const emitLeadStatusUpdate = (lead) => {
  if (ioInstance) {
    ioInstance.emit("lead:statusUpdated", lead);
  }
};

export { initSocket, emitNewLead, emitLeadStatusUpdate };
