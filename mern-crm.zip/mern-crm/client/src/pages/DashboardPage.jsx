import { motion } from "framer-motion";
import { Dashboard } from "../components/crm/Dashboard";

export default function DashboardPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white tracking-tight">Lead Dashboard</h1>
        <p className="text-gray-400 text-sm mt-1">
          Manage and respond to incoming leads in real-time.
        </p>
      </motion.div>
      <Dashboard />
    </div>
  );
}
