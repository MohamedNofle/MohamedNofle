import { motion } from "framer-motion";
import { LeadForm } from "../components/form/LeadForm";

export default function FormPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <span className="inline-block px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-4">
            Free Consultation
          </span>
          <h1 className="text-4xl font-bold text-white tracking-tight mb-3">
            Start Your Project
          </h1>
          <p className="text-gray-400 max-w-sm mx-auto text-sm leading-relaxed">
            Tell us about your needs and we'll craft the perfect solution for your business.
          </p>
        </motion.div>
        <LeadForm />
      </div>
    </div>
  );
}
