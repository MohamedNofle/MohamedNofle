import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { socket } from "../lib/socket";
import { LEADS_KEY } from "./useLeads";

export function useSocket(onNewLead) {
  const qc = useQueryClient();

  useEffect(() => {
    socket.connect();

    socket.on("new_lead", (lead) => {
      qc.setQueryData(LEADS_KEY, (prev) => [lead, ...(prev || [])]);
      onNewLead?.(lead);
    });

    socket.on("lead_updated", (updatedLead) => {
      qc.setQueryData(LEADS_KEY, (prev) =>
        prev?.map((l) => (l._id === updatedLead._id ? updatedLead : l))
      );
    });

    socket.on("lead_deleted", (id) => {
      qc.setQueryData(LEADS_KEY, (prev) => prev?.filter((l) => l._id !== id));
    });

    return () => {
      socket.off("new_lead");
      socket.off("lead_updated");
      socket.off("lead_deleted");
      socket.disconnect();
    };
  }, [qc, onNewLead]);
}
