import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { leadsApi } from "../lib/api";

export const LEADS_KEY = ["leads"];

export function useLeads() {
  return useQuery({ queryKey: LEADS_KEY, queryFn: leadsApi.getAll });
}

export function useUpdateLeadStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }) => leadsApi.updateStatus(id, status),
    onSuccess: (updatedLead) => {
      qc.setQueryData(LEADS_KEY, (prev) =>
        prev?.map((l) => (l._id === updatedLead._id ? updatedLead : l))
      );
    },
  });
}

export function useDeleteLead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id) => leadsApi.remove(id),
    onSuccess: (_, id) => {
      qc.setQueryData(LEADS_KEY, (prev) => prev?.filter((l) => l._id !== id));
    },
  });
}
