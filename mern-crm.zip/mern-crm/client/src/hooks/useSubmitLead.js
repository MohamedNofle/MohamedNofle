import { useMutation } from "@tanstack/react-query";
import { leadsApi } from "../lib/api";

export function useSubmitLead(onSuccess) {
  return useMutation({
    mutationFn: leadsApi.create,
    onSuccess,
  });
}
