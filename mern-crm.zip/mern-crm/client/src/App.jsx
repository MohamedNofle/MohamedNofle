import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { ToastProvider } from "./components/ui/ToastProvider";
import FormPage from "./pages/FormPage";
import DashboardPage from "./pages/DashboardPage";
import { LayoutDashboard, FileText } from "lucide-react";

function NavBar() {
  const base = "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200";
  const active = `${base} bg-emerald-500/10 text-emerald-400 border border-emerald-500/20`;
  const inactive = `${base} text-gray-400 hover:text-gray-200 hover:bg-gray-800`;

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 border-b border-gray-800 bg-gray-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
            <span className="text-white font-bold text-sm">C</span>
          </div>
          <span className="font-semibold text-white">CRM Pro</span>
        </div>
        <div className="flex items-center gap-2">
          <NavLink to="/" className={({ isActive }) => isActive ? active : inactive} end>
            <FileText size={16} /> Submit Lead
          </NavLink>
          <NavLink to="/dashboard" className={({ isActive }) => isActive ? active : inactive}>
            <LayoutDashboard size={16} /> Dashboard
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          <NavBar />
          <main className="pt-16 min-h-screen">
            <Routes>
              <Route path="/" element={<FormPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
            </Routes>
          </main>
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  );
}
