import { motion, AnimatePresence } from "framer-motion";
import { Bell, X } from "lucide-react";

const Toast = ({ notifications, onDismiss }) => (
  <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm">
    <AnimatePresence>
      {notifications.map((n) => (
        <motion.div
          key={n.id}
          initial={{ opacity: 0, x: 60, scale: 0.95 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 60, scale: 0.95 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="flex items-start gap-3 rounded-2xl bg-white p-4 shadow-xl ring-1 ring-gray-100"
        >
          <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-emerald-100">
            <Bell className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900">New Lead</p>
            <p className="mt-0.5 text-xs text-gray-500 truncate">{n.message}</p>
          </div>
          <button onClick={() => onDismiss(n.id)} className="text-gray-400 hover:text-gray-600">
            <X className="h-4 w-4" />
          </button>
        </motion.div>
      ))}
    </AnimatePresence>
  </div>
);

export default Toast;
