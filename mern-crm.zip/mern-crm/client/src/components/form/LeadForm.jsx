import { useState } from "react";
import { motion } from "framer-motion";
import { Send, User, Mail, Phone, Building2, Briefcase, DollarSign, MessageSquare } from "lucide-react";
import { leadFormSchema } from "../../lib/validators";
import { useSubmitLead } from "../../hooks/useSubmitLead";
import { useToast } from "../ui/ToastProvider";
import { FormField } from "./FormField";

const SECTORS = ["Technology", "Healthcare", "Finance", "Retail", "Manufacturing", "Education", "Real Estate", "Other"];
const BUDGETS = ["Under $5K", "$5K – $15K", "$15K – $50K", "$50K – $100K", "$100K+"];

const initialValues = { fullName: "", email: "", phone: "", company: "", sector: "", budget: "", message: "" };

export function LeadForm() {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const addToast = useToast();

  const { mutate, isPending } = useSubmitLead(() => {
    setSubmitted(true);
    setValues(initialValues);
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = leadFormSchema.safeParse(values);
    if (!result.success) {
      setErrors(result.error.flatten().fieldErrors);
      return;
    }
    setErrors({});
    mutate(result.data, {
      onError: () => addToast({ message: "Submission failed. Please try again.", type: "error" }),
    });
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-12 text-center"
      >
        <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto mb-6">
          <Send size={28} className="text-emerald-400" />
        </div>
        <h3 className="text-2xl font-semibold text-white mb-2">Lead Submitted!</h3>
        <p className="text-gray-400 mb-8">We've received your information and will be in touch soon.</p>
        <button className="btn-primary mx-auto" onClick={() => setSubmitted(false)}>
          Submit Another Lead
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="glass-card p-8"
    >
      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-white mb-1">Get in Touch</h2>
        <p className="text-gray-400 text-sm">Fill out the form and our team will reach out within 24 hours.</p>
      </div>

      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <FormField label="Full Name" error={errors.fullName?.[0]} required>
            <div className="relative">
              <User size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
              <input name="fullName" value={values.fullName} onChange={handleChange}
                placeholder="John Smith" className="input-field pl-10" />
            </div>
          </FormField>

          <FormField label="Email Address" error={errors.email?.[0]} required>
            <div className="relative">
              <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
              <input name="email" type="email" value={values.email} onChange={handleChange}
                placeholder="john@company.com" className="input-field pl-10" />
            </div>
          </FormField>

          <FormField label="Phone Number" error={errors.phone?.[0]} required>
            <div className="relative">
              <Phone size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
              <input name="phone" type="tel" value={values.phone} onChange={handleChange}
                placeholder="+1 (555) 000-0000" className="input-field pl-10" />
            </div>
          </FormField>

          <FormField label="Company" error={errors.company?.[0]}>
            <div className="relative">
              <Building2 size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
              <input name="company" value={values.company} onChange={handleChange}
                placeholder="Acme Inc." className="input-field pl-10" />
            </div>
          </FormField>

          <FormField label="Sector" error={errors.sector?.[0]} required>
            <div className="relative">
              <Briefcase size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
              <select name="sector" value={values.sector} onChange={handleChange} className="input-field pl-10 appearance-none">
                <option value="">Select sector</option>
                {SECTORS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </FormField>

          <FormField label="Budget Range" error={errors.budget?.[0]} required>
            <div className="relative">
              <DollarSign size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
              <select name="budget" value={values.budget} onChange={handleChange} className="input-field pl-10 appearance-none">
                <option value="">Select budget</option>
                {BUDGETS.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
          </FormField>
        </div>

        <FormField label="Message" error={errors.message?.[0]}>
          <div className="relative">
            <MessageSquare size={15} className="absolute left-3.5 top-3.5 text-gray-500" />
            <textarea name="message" value={values.message} onChange={handleChange}
              placeholder="Tell us about your project..." rows={4}
              className="input-field pl-10 resize-none" />
          </div>
        </FormField>

        <button type="submit" disabled={isPending} className="btn-primary w-full mt-2">
          {isPending ? (
            <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Submitting...</>
          ) : (
            <><Send size={16} /> Submit Lead</>
          )}
        </button>
      </form>
    </motion.div>
  );
}
