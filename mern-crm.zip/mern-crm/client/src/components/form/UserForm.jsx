import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { Send, CheckCircle, Building2, User, Mail, Phone, Briefcase, DollarSign, MessageSquare } from "lucide-react";
import { leadSchema } from "../../lib/schema";
import { useSubmitLead } from "../../hooks/useLeads";
import FormField from "./FormField";

const inputClass =
  "w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-900 placeholder-gray-400 outline-none ring-0 transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20";

const selectClass =
  "w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 appearance-none";

const SECTORS = [
  { value: "retail", label: "Retail & Commerce" },
  { value: "medical", label: "Medical & Healthcare" },
  { value: "construction", label: "Construction" },
  { value: "education", label: "Education & Training" },
  { value: "technology", label: "Technology" },
  { value: "other", label: "Other" },
];

const BUDGETS = [
  { value: "under-10k", label: "Under $10,000" },
  { value: "10k-50k", label: "$10,000 – $50,000" },
  { value: "50k-100k", label: "$50,000 – $100,000" },
  { value: "above-100k", label: "Above $100,000" },
];

const containerVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

const successVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.4, ease: "easeOut" } },
};

const UserForm = () => {
  const [submitted, setSubmitted] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(leadSchema) });

  const { mutate, isPending } = useSubmitLead({
    onSuccess: () => {
      setSubmitted(true);
      reset();
    },
  });

  const onSubmit = (data) => mutate(data);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50 flex items-center justify-center px-4 py-16">
      <AnimatePresence mode="wait">
        {submitted ? (
          <motion.div
            key="success"
            variants={successVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
            className="flex flex-col items-center gap-6 text-center max-w-sm"
          >
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100">
              <CheckCircle className="h-10 w-10 text-emerald-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Request Received</h2>
              <p className="mt-2 text-gray-500 text-sm leading-relaxed">
                Our team has been notified and will reach out within 24 hours.
              </p>
            </div>
            <button
              onClick={() => setSubmitted(false)}
              className="rounded-xl bg-emerald-600 px-8 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              Submit Another
            </button>
          </motion.div>
        ) : (
          <motion.div
            key="form"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="w-full max-w-2xl"
          >
            <div className="mb-10">
              <h1 className="text-4xl font-bold tracking-tight text-gray-900">
                Get a Free System Analysis
              </h1>
              <p className="mt-3 text-gray-500 leading-relaxed">
                Tell us about your business and we'll deliver a tailored proposal within 24 hours.
              </p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <FormField label="Full Name" error={errors.fullName?.message}>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register("fullName")}
                      placeholder="John Anderson"
                      className={`${inputClass} pl-10`}
                    />
                  </div>
                </FormField>

                <FormField label="Company" error={errors.company?.message}>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register("company")}
                      placeholder="Acme Corp"
                      className={`${inputClass} pl-10`}
                    />
                  </div>
                </FormField>

                <FormField label="Email Address" error={errors.email?.message}>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register("email")}
                      type="email"
                      placeholder="john@acme.com"
                      className={`${inputClass} pl-10`}
                    />
                  </div>
                </FormField>

                <FormField label="Phone Number" error={errors.phone?.message}>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      {...register("phone")}
                      type="tel"
                      placeholder="+1 555 000 0000"
                      className={`${inputClass} pl-10`}
                    />
                  </div>
                </FormField>

                <FormField label="Industry Sector" error={errors.sector?.message}>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                    <select {...register("sector")} className={`${selectClass} pl-10`} defaultValue="">
                      <option value="" disabled>Select a sector</option>
                      {SECTORS.map((s) => (
                        <option key={s.value} value={s.value}>{s.label}</option>
                      ))}
                    </select>
                  </div>
                </FormField>

                <FormField label="Budget Range" error={errors.budget?.message}>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                    <select {...register("budget")} className={`${selectClass} pl-10`} defaultValue="">
                      <option value="" disabled>Select a range</option>
                      {BUDGETS.map((b) => (
                        <option key={b.value} value={b.value}>{b.label}</option>
                      ))}
                    </select>
                  </div>
                </FormField>
              </div>

              <FormField label="Message (Optional)" error={errors.message?.message}>
                <div className="relative">
                  <MessageSquare className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                  <textarea
                    {...register("message")}
                    rows={4}
                    placeholder="Describe your current challenges or goals..."
                    className={`${inputClass} pl-10 resize-none`}
                  />
                </div>
              </FormField>

              <motion.button
                type="submit"
                disabled={isPending}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-8 py-4 text-sm font-semibold text-white transition hover:bg-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {isPending ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
                {isPending ? "Sending..." : "Submit Request"}
              </motion.button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default UserForm;
