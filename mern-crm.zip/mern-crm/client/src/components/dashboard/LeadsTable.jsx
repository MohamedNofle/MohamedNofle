import { motion } from "framer-motion";
import { CheckCircle, XCircle, Trash2 } from "lucide-react";
import StatusBadge from "./StatusBadge";
import { useUpdateLeadStatus, useDeleteLead } from "../../hooks/useLeads";

const SECTOR_LABELS = {
  retail: "Retail", medical: "Medical", construction: "Construction",
  education: "Education", technology: "Technology", other: "Other",
};

const BUDGET_LABELS = {
  "under-10k": "< $10k", "10k-50k": "$10k–50k",
  "50k-100k": "$50k–100k", "above-100k": "> $100k",
};

const rowVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: (i) => ({ opacity: 1, y: 0, transition: { delay: i * 0.04, duration: 0.3 } }),
};

const LeadsTable = ({ leads }) => {
  const { mutate: updateStatus, isPending: isUpdating } = useUpdateLeadStatus();
  const { mutate: deleteLead, isPending: isDeleting } = useDeleteLead();

  if (!leads?.length) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-gray-400">
        <p className="text-lg font-medium">No leads yet</p>
        <p className="text-sm mt-1">Submissions from the form will appear here in real-time.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-2xl ring-1 ring-gray-200">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-100 bg-gray-50">
            {["Name", "Contact", "Company", "Sector", "Budget", "Status", "Date", "Actions"].map((h) => (
              <th key={h} className="px-5 py-3.5 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-50">
          {leads.map((lead, i) => (
            <motion.tr
              key={lead._id}
              custom={i}
              variants={rowVariants}
              initial="hidden"
              animate="visible"
              className="hover:bg-gray-50/60 transition-colors"
            >
              <td className="px-5 py-4 font-medium text-gray-900 whitespace-nowrap">{lead.fullName}</td>
              <td className="px-5 py-4 whitespace-nowrap">
                <div className="text-gray-700">{lead.email}</div>
                <div className="text-gray-400 text-xs mt-0.5">{lead.phone}</div>
              </td>
              <td className="px-5 py-4 text-gray-600 whitespace-nowrap">{lead.company || "—"}</td>
              <td className="px-5 py-4 text-gray-600 whitespace-nowrap">{SECTOR_LABELS[lead.sector] ?? lead.sector}</td>
              <td className="px-5 py-4 text-gray-600 whitespace-nowrap">{BUDGET_LABELS[lead.budget] ?? lead.budget}</td>
              <td className="px-5 py-4 whitespace-nowrap">
                <StatusBadge status={lead.status} />
              </td>
              <td className="px-5 py-4 text-gray-400 whitespace-nowrap text-xs">
                {new Date(lead.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
              </td>
              <td className="px-5 py-4 whitespace-nowrap">
                <div className="flex items-center gap-2">
                  {lead.status === "pending" && (
                    <>
                      <button
                        onClick={() => updateStatus({ id: lead._id, status: "accepted" })}
                        disabled={isUpdating}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 transition hover:bg-emerald-100 disabled:opacity-50"
                      >
                        <CheckCircle className="h-3.5 w-3.5" />
                        Accept
                      </button>
                      <button
                        onClick={() => updateStatus({ id: lead._id, status: "rejected" })}
                        disabled={isUpdating}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-600 transition hover:bg-red-100 disabled:opacity-50"
                      >
                        <XCircle className="h-3.5 w-3.5" />
                        Reject
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => deleteLead(lead._id)}
                    disabled={isDeleting}
                    className="inline-flex items-center justify-center rounded-lg p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-red-500 disabled:opacity-50"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LeadsTable;
