import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { LayoutDashboard, Users, CheckCircle2, Clock, XCircle } from "lucide-react";
import { useLeads } from "../../hooks/useLeads";
import { useSocket } from "../../hooks/useSocket";
import LeadsTable from "./LeadsTable";
import Toast from "../ui/Toast";

const StatCard = ({ icon: Icon, label, value, color }) => (
  <div className="flex items-center gap-4 rounded-2xl bg-white p-5 ring-1 ring-gray-100">
    <div className={`flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl ${color}`}>
      <Icon className="h-5 w-5" />
    </div>
    <div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-xs font-medium text-gray-500 mt-0.5">{label}</p>
    </div>
  </div>
);

const CRMDashboard = () => {
  const { data: leads = [], isLoading } = useLeads();
  const [notifications, setNotifications] = useState([]);

  const handleNewLead = useCallback((lead) => {
    const id = Date.now();
    setNotifications((prev) => [
      ...prev,
      { id, message: `${lead.fullName} from ${lead.company || lead.sector}` },
    ]);
    setTimeout(() => setNotifications((prev) => prev.filter((n) => n.id !== id)), 5000);
  }, []);

  useSocket(handleNewLead);

  const dismissNotification = (id) =>
    setNotifications((prev) => prev.filter((n) => n.id !== id));

  const total    = leads.length;
  const accepted = leads.filter((l) => l.status === "accepted").length;
  const rejected = leads.filter((l) => l.status === "rejected").length;
  const pending  = leads.filter((l) => l.status === "pending").length;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b border-gray-200 bg-white">
        <div className="mx-auto max-w-7xl px-6 py-5 flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-600">
            <LayoutDashboard className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-900">Nizami CRM</h1>
            <p className="text-xs text-gray-500">Lead Management Dashboard</p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-8 flex flex-col gap-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="grid grid-cols-2 gap-4 sm:grid-cols-4"
        >
          <StatCard icon={Users}        label="Total Leads"     value={total}    color="bg-blue-50 text-blue-600" />
          <StatCard icon={Clock}        label="Pending"         value={pending}  color="bg-amber-50 text-amber-600" />
          <StatCard icon={CheckCircle2} label="Accepted"        value={accepted} color="bg-emerald-50 text-emerald-600" />
          <StatCard icon={XCircle}      label="Rejected"        value={rejected} color="bg-red-50 text-red-500" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-semibold text-gray-900">All Leads</h2>
            <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-600">
              {total} total
            </span>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-24">
              <span className="h-7 w-7 animate-spin rounded-full border-2 border-emerald-600 border-t-transparent" />
            </div>
          ) : (
            <LeadsTable leads={leads} />
          )}
        </motion.div>
      </main>

      <Toast notifications={notifications} onDismiss={dismissNotification} />
    </div>
  );
};

export default CRMDashboard;
