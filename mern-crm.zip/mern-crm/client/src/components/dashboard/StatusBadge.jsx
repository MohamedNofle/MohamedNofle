const config = {
  pending:  { label: "Pending",  className: "bg-amber-50 text-amber-700 ring-amber-200" },
  accepted: { label: "Accepted", className: "bg-emerald-50 text-emerald-700 ring-emerald-200" },
  rejected: { label: "Rejected", className: "bg-red-50 text-red-700 ring-red-200" },
};

const StatusBadge = ({ status }) => {
  const { label, className } = config[status] ?? config.pending;
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${className}`}>
      {label}
    </span>
  );
};

export default StatusBadge;
