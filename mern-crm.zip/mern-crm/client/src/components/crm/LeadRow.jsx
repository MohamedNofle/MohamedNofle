import { motion } from "framer-motion";
import { CheckCircle, XCircle, Trash2 } from "lucide-react";
import { StatusBadge } from "../ui/StatusBadge";
import { useUpdateLeadStatus, useDeleteLead } from "../../hooks/useLeads";
import { useToast } from "../ui/ToastProvider";

export function LeadRow({ lead, index }) {
  const addToast = useToast();
  const { mutate: updateStatus, isPending: isUpdating } = useUpdateLeadStatus();
  const { mutate: deleteLead, isPending: isDeleting } = useDeleteLead();

  const handleStatus = (status) => {
    updateStatus(
      { id: lead._id, status },
      { onSuccess: () => addToast({ message: `Lead ${status}`, type: status === "accepted" ? "success" : "error" }) }
    );
  };

  const handleDelete = () => {
    deleteLead(lead._id, {
      onSuccess: () => addToast({ message: "Lead deleted", type: "info" }),
    });
  };

  const isDisabled = isUpdating || isDeleting || lead.status !== "pending";

  return (
    <motion.tr
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04 }}
      className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors"
    >
      <td className="px-4 py-4">
        <div>
          <p className="text-sm font-medium text-white">{lead.fullName}</p>
          <p className="text-xs text-gray-500">{lead.company || "—"}</p>
        </div>
      </td>
      <td className="px-4 py-4">
        <p className="text-sm text-gray-300">{lead.email}</p>
        <p className="text-xs text-gray-500">{lead.phone}</p>
      </td>
      <td className="px-4 py-4 text-sm text-gray-400">{lead.sector}</td>
      <td className="px-4 py-4 text-sm text-gray-400">{lead.budget}</td>
      <td className="px-4 py-4"><StatusBadge status={lead.status} /></td>
      <td className="px-4 py-4 text-xs text-gray-500">
        {new Date(lead.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
      </td>
      <td className="px-4 py-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleStatus("accepted")}
            disabled={isDisabled}
            title="Accept"
            className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <CheckCircle size={16} />
          </button>
          <button
            onClick={() => handleStatus("rejected")}
            disabled={isDisabled}
            title="Reject"
            className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <XCircle size={16} />
          </button>
          <button
            onClick={handleDelete}
            disabled={isDeleting}
            title="Delete"
            className="p-1.5 rounded-lg bg-gray-700/50 text-gray-400 hover:bg-gray-700 hover:text-red-400 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </td>
    </motion.tr>
  );
}
