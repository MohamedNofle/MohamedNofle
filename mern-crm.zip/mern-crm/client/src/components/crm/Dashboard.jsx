import { motion } from "framer-motion";
import { Users, CheckCircle, XCircle, Clock } from "lucide-react";
import { useLeads } from "../../hooks/useLeads";
import { useSocket } from "../../hooks/useSocket";
import { useToast } from "../ui/ToastProvider";
import { LeadTable } from "./LeadTable";

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card p-5 flex items-center gap-4"
    >
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
        <Icon size={20} />
      </div>
      <div>
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-xs text-gray-500">{label}</p>
      </div>
    </motion.div>
  );
}

export function Dashboard() {
  const { data: leads = [], isLoading } = useLeads();
  const addToast = useToast();

  useSocket((newLead) => {
    addToast({ message: `New lead from ${newLead.fullName}`, type: "success", duration: 6000 });
  });

  const stats = {
    total: leads.length,
    pending: leads.filter((l) => l.status === "pending").length,
    accepted: leads.filter((l) => l.status === "accepted").length,
    rejected: leads.filter((l) => l.status === "rejected").length,
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Leads" value={stats.total} color="bg-blue-500/10 text-blue-400" />
        <StatCard icon={Clock} label="Pending" value={stats.pending} color="bg-amber-500/10 text-amber-400" />
        <StatCard icon={CheckCircle} label="Accepted" value={stats.accepted} color="bg-emerald-500/10 text-emerald-400" />
        <StatCard icon={XCircle} label="Rejected" value={stats.rejected} color="bg-red-500/10 text-red-400" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="glass-card overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-gray-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white">All Leads</h2>
            <p className="text-xs text-gray-500 mt-0.5">Real-time updates via WebSocket</p>
          </div>
          <div className="flex items-center gap-2 text-xs text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Live
          </div>
        </div>
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <span className="w-6 h-6 border-2 border-gray-700 border-t-emerald-500 rounded-full animate-spin" />
          </div>
        ) : (
          <LeadTable leads={leads} />
        )}
      </motion.div>
    </div>
  );
}
