import { motion } from "framer-motion";
import { Inbox } from "lucide-react";
import { LeadRow } from "./LeadRow";

const columns = ["Name", "Contact", "Sector", "Budget", "Status", "Date", "Actions"];

export function LeadTable({ leads }) {
  if (!leads.length) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-20 text-gray-500"
      >
        <Inbox size={40} className="mx-auto mb-3 opacity-40" />
        <p className="text-sm">No leads yet. Submit the form to see them here.</p>
      </motion.div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[800px]">
        <thead>
          <tr className="border-b border-gray-800">
            {columns.map((col) => (
              <th key={col} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {leads.map((lead, i) => (
            <LeadRow key={lead._id} lead={lead} index={i} />
          ))}
        </tbody>
      </table>
    </div>
  );
}
