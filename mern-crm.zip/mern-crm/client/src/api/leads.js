import axios from "axios";

const api = axios.create({ baseURL: "/api" });

export const fetchLeads = async () => {
  const { data } = await api.get("/leads");
  return data.data;
};

export const submitLead = async (payload) => {
  const { data } = await api.post("/leads", payload);
  return data.data;
};

export const updateLeadStatus = async ({ id, status }) => {
  const { data } = await api.patch(`/leads/${id}/status`, { status });
  return data.data;
};

export const deleteLead = async (id) => {
  const { data } = await api.delete(`/leads/${id}`);
  return data;
};
