# MERN CRM — Full Stack Lead Management

## Stack
- **Frontend**: React + Vite + Tailwind CSS + Framer Motion + TanStack Query + Zod + Socket.io-client
- **Backend**: Node.js + Express + MongoDB + Mongoose + Socket.io + Zod

## File Structure
```
mern/
├── server/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   └── src/
│       ├── config/db.js
│       ├── models/Lead.js
│       ├── schemas/leadSchema.js
│       ├── middleware/validateRequest.js
│       ├── controllers/leadController.js
│       ├── routes/leadRoutes.js
│       └── socket/socketHandler.js
│
└── client/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    ├── postcss.config.js
    ├── .env.example
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css
        ├── lib/
        │   ├── queryClient.js
        │   ├── socket.js
        │   ├── api.js
        │   └── validators.js
        ├── hooks/
        │   ├── useLeads.js
        │   ├── useSubmitLead.js
        │   └── useSocket.js
        ├── components/
        │   ├── form/
        │   │   ├── LeadForm.jsx
        │   │   └── FormField.jsx
        │   ├── crm/
        │   │   ├── Dashboard.jsx
        │   │   ├── LeadTable.jsx
        │   │   └── LeadRow.jsx
        │   └── ui/
        │       ├── ToastProvider.jsx
        │       └── StatusBadge.jsx
        └── pages/
            ├── FormPage.jsx
            └── DashboardPage.jsx
```

## Setup & Run

### 1. Server
```bash
cd server
cp .env.example .env
# Edit .env with your MongoDB URI
npm install
npm run dev
```

### 2. Client
```bash
cd client
cp .env.example .env
npm install
npm run dev
```

### 3. Open
- Form: http://localhost:5173
- Dashboard: http://localhost:5173/dashboard

## API Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/leads | Get all leads |
| POST | /api/leads | Create new lead |
| PATCH | /api/leads/:id/status | Accept or reject |
| DELETE | /api/leads/:id | Delete lead |

## Real-time Events (Socket.io)
| Event | Trigger |
|-------|---------|
| `new_lead` | New form submission |
| `lead_updated` | Status changed |
| `lead_deleted` | Lead removed |
